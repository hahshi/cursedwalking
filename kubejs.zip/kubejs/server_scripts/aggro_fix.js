EntityEvents.hurt(event => {
    const entity = event.entity;
    const attacker = event.source.actual;

    if (
        attacker &&
        // attacker.type === 'minecraft:player' &&
        entity.setTarget &&
        entity.id !== attacker.id
    ) {
        const dx = entity.x - attacker.x;
        const dz = entity.z - attacker.z;
        const distSq = dx * dx + dz * dz; // 2D horizontal distance only

        if (distSq <= 90) {
            entity.setTarget(attacker);
            // const dist = Math.sqrt(distSq).toFixed(1);
            // Utils.server.tell(`[Aggro Fix 3] ${entity.type.split(':')[1]} hit! Switching focus to ${attacker.name.string}. Distance: ${dist} blocks.`);
        }
    }
});