const MAX_GOLEMS = 5

// Create the team when the server starts
ServerEvents.loaded(event => {
  event.server.runCommandSilent('team add humans')
  event.server.runCommandSilent('team modify humans friendlyFire false')
})

// When an iron golem spawns or loads in
EntityEvents.spawned('minecraft:iron_golem', event => {
  const golem = event.entity
  const server = event.server

  // Add to team
  server.runCommandSilent(`team join humans ${golem.uuid}`)

  // Remember when this golem was first spawned (only set once)
  if (!golem.persistentData.contains('golemSpawnTime')) {
    golem.persistentData.putLong('golemSpawnTime', Date.now())
  }

  // Wait 1 tick so the new golem is actually in the world, then check the count
  server.scheduleInTicks(1, () => {
    let golems = []
    server.allLevels.forEach(level => {
      level.getEntities().forEach(e => {
        if (String(e.type) == 'minecraft:iron_golem' && e.alive) golems.push(e)
      })
    })

    if (golems.length <= MAX_GOLEMS) return

    // Oldest first, then kill the extras
    golems.sort((a, b) =>
      a.persistentData.getLong('golemSpawnTime') - b.persistentData.getLong('golemSpawnTime'))

    for (let i = 0; i < golems.length - MAX_GOLEMS; i++) {
      golems[i].kill()
    }
  })
})

// Add players to the team when they log in
PlayerEvents.loggedIn(event => {
  event.server.runCommandSilent(`team join humans ${event.player.username}`)
})